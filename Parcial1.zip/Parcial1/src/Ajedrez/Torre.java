package Ajedrez;

public class Torre extends Pieza{
	
	protected double posicionInicialX; 
	protected double posicionInicialY;

	public Torre(double x, double y, double inicialX, double inicialY) {
		super(x, y);
		this.posicionInicialX = inicialX;
		this.posicionInicialY = inicialY;
	}

	@Override
	public double calcularCasillas() {
		// TODO Auto-generated method stub
		return 0;
	}

}
