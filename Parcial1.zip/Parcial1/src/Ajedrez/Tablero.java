package Ajedrez;

public class Tablero {
	
	public static void main(String[] args)
	{
	}

}
