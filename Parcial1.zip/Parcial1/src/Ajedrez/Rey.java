package Ajedrez;

public class Rey extends Pieza{
	
	protected double posicionInicialX; 
	protected double posicionInicialY;

	public Rey(double x, double y, double inicialX, double inicialY) {
		super(x, y);
		this.posicionInicialX = inicialX;
		this.posicionInicialY = inicialY;
	}

	@Override
	public double calcularCasillas() {
		// TODO Auto-generated method stub
		return 0;
	}

}
