package Ajedrez;

public class Peon extends Pieza{
	
	protected double posicionInicialX; 
	protected double posicionInicialY; 
	protected double cantidadCasillas;

	public Peon(double x, double y, double inicialX, double inicialY) {
		super(x, y);
		this.posicionInicialX = inicialX;
		this.posicionInicialY = inicialY;
	}
	
	@Override
	public double calcularCasillas() {	
		return 0;
	}

	
}
