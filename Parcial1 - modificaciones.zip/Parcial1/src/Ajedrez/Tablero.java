package Ajedrez;

public class Tablero {
	
	public static void main(String[] args)
	{
		int tablero[][] = new int[8][8];
	}

}
