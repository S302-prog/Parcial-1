package Ajedrez;

public abstract class Pieza{
	
	protected double posicionX; 
	protected double posicionY;
	
	public double getPosicionX() {
		return posicionX;
	}
	public void setPosicionX(int posicionX) {
		this.posicionX = posicionX;
	}
	public double getPosicionY() {
		return posicionY;
	}
	public void setPosicionY(int posicionY) {
		this.posicionY = posicionY;
	}
	
	public Pieza(double x, double y)
	{
		this.posicionX = x;
		this.posicionY = y;
		
	}
	
	public abstract double calcularCasillas();

}
